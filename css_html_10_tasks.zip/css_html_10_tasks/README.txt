HTML + CSS Practical Assignment — 10 Tasks

Contents:
- 01_portfolio.html through 10_complete_layout.html: the 10 task pages
- styles.css: shared stylesheet used by every page

How to run:
1. Download and extract the ZIP.
2. Open the extracted css_html_10_tasks folder in VS Code.
3. Open any numbered HTML file and use Live Server or open it in a browser.
4. Keep styles.css in the same folder as the HTML files.

Notes:
- This is a front-end demonstration. Form submissions do not save data to a server.
- Gallery and hero photos load from Unsplash and require an internet connection.
- Task 2 uses fixed backgrounds on desktop; the effect is changed to scroll on small screens for better mobile usability.
