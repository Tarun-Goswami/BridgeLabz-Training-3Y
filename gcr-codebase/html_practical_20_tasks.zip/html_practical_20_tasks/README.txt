HTML Practical Assignment — 20 Tasks

How to use:
1. Extract this folder.
2. Open the folder in VS Code.
3. Open any numbered .html file and run it in a browser.
4. For Task 3, keep introduction.html and hobby.html in this same folder.
5. For Task 4, keep navigation.html, welcome.html, home.html, about.html, and contact.html in this same folder.
6. For Task 17, keep result.html beside 17_form.html.

Notes:
- Some iframe sites may block embedding due to their security settings.
- Task 4 uses obsolete frameset/frame tags because the assignment specifically asks for them.
- Forms are front-end demonstrations; action="#" does not save or process data on a server.
- Do not enter real payment card details into the demo payment form.
